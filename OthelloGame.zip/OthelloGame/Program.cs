﻿using System;

namespace OthelloGame
{
    public class Program
    {
        public static void Main()
        {
            GameManager gameManager = new GameManager();
            gameManager.Start();
        }
    }
}